﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class gController : MonoBehaviour
{


    public TMP_Text  Scenelablel;
    public TMP_Text Score;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        switch (Input.deviceOrientation)
        {
            case DeviceOrientation.LandscapeLeft:
                Score.rectTransform.localPosition = new Vector3(-1000.0f, 600.0f);
                break;

            case DeviceOrientation.LandscapeRight:
                Scenelablel.rectTransform.localPosition = new Vector3(1000.0f, 600.0f);
                break;

            case DeviceOrientation.Portrait:
                Scenelablel.text = "Portrait";
                break;
            case DeviceOrientation.Unknown:
                Scenelablel.text = "Unknown";
                break;

        }
    }
}
