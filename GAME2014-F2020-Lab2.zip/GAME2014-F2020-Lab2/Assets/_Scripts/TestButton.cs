﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class TestButton : MonoBehaviour
{


    public TMP_Text Score;
    public TMP_Text Scenelablel;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnNextButtonPressed()
    {

        // Score.rectTransform.position = new Vector3(-349.0f, -105f);

        Scenelablel.rectTransform.localPosition = new Vector3(1000.0f, 600.0f);
        Score.rectTransform.localPosition = new Vector3(-1000.0f, 600.0f);
    }
}
